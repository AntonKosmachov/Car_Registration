﻿--Создание базы данных
CREATE DATABASE lab_1

GO
ALTER DATABASE lab_1 SET RECOVERY SIMPLE
GO
use Lab_1
go
create table State_Automobile_Inspectorate
( 
[Officer code] int identity NOT NULL, 
[Name]  nvarchar(50)  NULL,
[Rank]  nvarchar(50)   NULL,
[Responsibilities] nvarchar(50)   NULL,
[Requirements] nvarchar(50)  NULL,
primary key ([Officer code])
) 
create table Car
( 
[Car code] int identity NOT NULL, 
[Mark code] int  NULL,
[Ownew code] int  NULL,
[Registration number] nvarchar(50)   NULL,
[Car body number] nvarchar(50)   NULL,
[Engine number] nvarchar(50)   NULL,
[Technical Passport] nvarchar(50)  NULL,
[Release date] date  NULL,
[Registration date] date  NULL,
[Latest inspection] date  NULL,
[Colour] nvarchar(50)   NULL,
[Description] nvarchar(50)  NULL,
primary key ([Car code])
)
create table [Owner]
( 
[Ownew code] int identity NOT NULL, 
[Name] nvarchar(50)  NULL,
[Birthday] date  NULL,
[Adress] nvarchar(50)  NULL,
[Passport data] nvarchar(50)  NULL,
[Number of driving license] nvarchar(50)  NULL,
[Date of issue] date NULL,
[Category] nvarchar(50) NULL,
[Additional Information] nvarchar(50)  NULL,
primary key ([Ownew code])
)  

create table Mark
(
[Mark code] int identity NOT NULL,
[Firm] nvarchar(50) NULL,
[Manufacturer country] nvarchar(50)  NULL,
primary key ([Mark code])
)

create table Accounting
(
[Accounting code] int identity NOT NULL,
[Officer code] int  NULL,
[Car code] int  NULL,
primary key ([Accounting code])
)

create table Theft
(
[Code theft] int identity NOT NULL,
[Accounting code] int NULL,
[Date theft] date  NULL,
[Spent Date] date  NULL,
primary key ([Code theft])
)

 go 
 -- Добавление связей между таблицами

ALTER TABLE dbo.Accounting  WITH CHECK ADD  CONSTRAINT FK_Accounting_Officer FOREIGN KEY([Officer code])
REFERENCES dbo.State_Automobile_Inspectorate ([Officer code]) ON DELETE CASCADE
GO
ALTER TABLE dbo.Theft  WITH CHECK ADD  CONSTRAINT FK_Theft_Accounting FOREIGN KEY([Accounting code])
REFERENCES dbo.Accounting ([Accounting code]) ON DELETE CASCADE
GO
ALTER TABLE dbo.Car  WITH CHECK ADD  CONSTRAINT FK_Car_Mark FOREIGN KEY([Mark code])
REFERENCES dbo.Mark ([Mark code]) ON DELETE CASCADE
GO
ALTER TABLE dbo.Car  WITH CHECK ADD  CONSTRAINT FK_Car_Owner FOREIGN KEY([Ownew code])
REFERENCES dbo.[Owner] ([Ownew code]) ON DELETE CASCADE
GO
ALTER TABLE dbo.Accounting  WITH CHECK ADD  CONSTRAINT FK_Accounting_Car FOREIGN KEY([Car code])
REFERENCES dbo.Car ([Car code]) ON DELETE CASCADE
GO


use [Lab_1]
SET NOCOUNT ON


DECLARE @Symbol CHAR(52)= 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz',
		@Position INT,
		@i INT,
		@NameLimit INT,
		
		--===================
		@FirmName nvarchar(50),
		@Manufacturer_country_name nvarchar(50),
		--===================
		@Date_of_issue date,
		@Birthday date,
		@OwnerName nvarchar(50),
		@Adress nvarchar(50),
		@Passport_data nvarchar(50),
		@Number_of_driving_license nvarchar(50),
		@Category nvarchar(50),
		@Additional_Information nvarchar(50), 
		--===================
		@Name_Officer nvarchar(50),
		@Rank nvarchar(50),
		@Responsibilities nvarchar(50),
		@Requirements nvarchar(50),
		--===================
		@Registration_number nvarchar(50) ,
		@Car_body_number nvarchar(50) ,
		@Engine_number nvarchar(50),
		@Technical_Passport nvarchar(50),
		@Release_date date,
		@Registration_date date,
		@Latest_inspection date,
		@Colour nvarchar(50)  ,
		@Description nvarchar(50),

		--=================== 
		@Date_theft date  ,
		@Spent_date date  ,
		--=================== 
		



		
		
		@RowCount INT,
		@More_than_a_thousand int,
		@More_than_a_hundred int,
		@NumberOperations int




SET @More_than_a_thousand =1000
SET @More_than_a_hundred =  100
SET @NumberOperations =  300000

BEGIN TRAN

SELECT @i=0 FROM dbo.Mark WITH (TABLOCKX) WHERE 1=0
--=========================================================
-- Марки машин-100
--=========================================================
	SET @RowCount=1
	
WHILE @RowCount<=@More_than_a_hundred
	BEGIN
		
		SET @FirmName=''
		SET @Manufacturer_country_name=''
		SET @NameLimit=5+RAND()*15 -- им¤ от 5 до 20 символов
			

		SET @i=1

		WHILE @i<=@NameLimit
		BEGIN
			SET @Position=RAND()*52
			SET @FirmName = @FirmName + SUBSTRING(@Symbol, @Position, 1)
			SET @Position=RAND()*52
			SET @Manufacturer_country_name=@Manufacturer_country_name + SUBSTRING(@Symbol, @Position, 1)
			SET @i=@i+1
		END

		INSERT INTO dbo.Mark(Firm , [Manufacturer country]) 
		SELECT @FirmName, @Manufacturer_country_name
		

		SET @RowCount +=1
	END
--=========================================================
-- Владельцы машин -100
--=========================================================

SELECT @i=0 FROM dbo.[Owner] WITH (TABLOCKX) WHERE 1=0

	SET @RowCount=1
	
WHILE @RowCount<=@More_than_a_hundred
	BEGIN
		
		SET @OwnerName=''
		SET @Adress=''
		SET @Passport_data=''
		SET @Number_of_driving_license=''
		SET @Date_of_issue=''
		SET @Category=''
		SET @Manufacturer_country_name=''
		SET @Additional_Information=''
		SET @NameLimit=5+RAND()*15 -- им¤ от 5 до 20 символов
		SET @Birthday=dateadd(day,-RAND()*15000,GETDATE())
		SET @Date_of_issue =dateadd(day,-RAND()*15000,GETDATE())
		SET @i=1

		WHILE @i<=@NameLimit
		BEGIN
			
			SET @Position=RAND()*52
			SET @OwnerName = @OwnerName + SUBSTRING(@Symbol, @Position, 1)
			SET @Position=RAND()*52
			SET @Adress=@Adress + SUBSTRING(@Symbol, @Position, 1)
			SET @Position=RAND()*52
			SET @Passport_data = @Passport_data + SUBSTRING(@Symbol, @Position, 1)
			SET @Position=RAND()*52
			SET @Number_of_driving_license=@Number_of_driving_license + SUBSTRING(@Symbol, @Position, 1)
			SET @Position=RAND()*52
			
			SET @Position=RAND()*52
			SET @Category=@Category + SUBSTRING(@Symbol, @Position, 1)
			SET @Position=RAND()*52
			SET @Manufacturer_country_name = @Manufacturer_country_name + SUBSTRING(@Symbol, @Position, 1)
			SET @Position=RAND()*52
			SET @Additional_Information=@Additional_Information + SUBSTRING(@Symbol, @Position, 1)
			SET @i=@i+1
		END

		INSERT INTO dbo.[Owner](Name, [Birthday], [Adress], [Passport data], [Number of driving license], [Date of issue],[Category],[Additional Information]) 
		SELECT @OwnerName,@Birthday,@Adress,@Passport_data,@Number_of_driving_license,@Date_of_issue,@Category,@Additional_Information
		

		SET @RowCount +=1
	END

--=========================================================
-- ГАИ -100
--=========================================================

SELECT @i=0 FROM dbo.State_Automobile_Inspectorate WITH (TABLOCKX) WHERE 1=0

	SET @RowCount=1
	
WHILE @RowCount<=@More_than_a_hundred
	BEGIN
		
		SET @Name_Officer=''
		SET @Rank=''
		SET @Responsibilities=''
		SET @Requirements=''
		SET @NameLimit=5+RAND()*15 -- им¤ от 5 до 20 символов
		SET @i=1


		WHILE @i<=@NameLimit
		BEGIN
			
			SET @Position=RAND()*52
			SET @Name_Officer = @Name_Officer + SUBSTRING(@Symbol, @Position, 1)
			SET @Position=RAND()*52
			SET @Rank=@Rank + SUBSTRING(@Symbol, @Position, 1)
			SET @Position=RAND()*52
			SET @Responsibilities = @Responsibilities + SUBSTRING(@Symbol, @Position, 1)
			SET @Position=RAND()*52
			SET @Requirements=@Requirements + SUBSTRING(@Symbol, @Position, 1)
			SET @i=@i+1
		END

		INSERT INTO dbo.State_Automobile_Inspectorate(Name,[Rank],Responsibilities,Requirements) 
		SELECT @Name_Officer,@Rank,@Responsibilities,@Requirements
		

		SET @RowCount +=1
	END

--=========================================================
-- Автомобили -3000
--=========================================================

SELECT @RowCount=1 FROM dbo.Car WITH (TABLOCKX) WHERE 1=0

	
	
WHILE @RowCount<=@NumberOperations
	BEGIN
		
		SET @Registration_number=''
		SET @Car_body_number=''
		SET @Engine_number=''
		SET @Technical_Passport=''
		SET @Colour=''
		SET @Description=''
		SET @NameLimit=5+RAND()*15 -- им¤ от 5 до 20 символов
		SET @i=1
		SET @Release_date=dateadd(day,-RAND()*15000,GETDATE())
		SET @Registration_date =dateadd(day,-RAND()*15000,GETDATE())
		SET @Latest_inspection =dateadd(day,-RAND()*15000,GETDATE())
		
	

		WHILE @i<=@NameLimit
		BEGIN
			
			SET @Position=RAND()*52
			SET @Registration_number = @Registration_number + SUBSTRING(@Symbol, @Position, 1)
			SET @Position=RAND()*52
			SET @Car_body_number=@Car_body_number + SUBSTRING(@Symbol, @Position, 1)
			SET @Position=RAND()*52
			SET @Engine_number = @Engine_number + SUBSTRING(@Symbol, @Position, 1)
			SET @Position=RAND()*52
			SET @Technical_Passport=@Technical_Passport + SUBSTRING(@Symbol, @Position, 1)
			SET @Position=RAND()*52
			SET @Colour = @Colour + SUBSTRING(@Symbol, @Position, 1)
			SET @Position=RAND()*52
			SET @Description=@Description + SUBSTRING(@Symbol, @Position, 1)
			SET @i=@i+1
		END

		INSERT INTO dbo.Car([Mark code],[Ownew code],[Registration number],[Car body number],[Engine number],[Technical Passport],[Release date],[Registration date],[Latest inspection],Colour,[Description]) 
		SELECT
		CAST( (1+RAND()*(@More_than_a_hundred-1)) as int),
		CAST( (1+RAND()*(@More_than_a_hundred-1)) as int),
		@Registration_number,@Car_body_number,@Engine_number,@Technical_Passport,@Release_date,@Registration_date,@Latest_inspection,@Colour,@Description
		

		SET @RowCount +=1
	END
--=========================================================
--Учет  -100
--=========================================================

SELECT @i=0 FROM dbo.Theft WITH (TABLOCKX) WHERE 1=0

	SET @RowCount=1
	
WHILE @RowCount<=@More_than_a_hundred
	BEGIN
		
		
		SET @NameLimit=5+RAND()*15 -- им¤ от 5 до 20 символов
		SET @i=1
		WHILE @i<=@NameLimit
		BEGIN
			
			SET @i=@i+1
		END

		INSERT INTO dbo.Accounting([Officer code],[Car code] )
		SELECT
		 CAST( (1+RAND()*(@More_than_a_hundred-1)) as int),CAST( (1+RAND()*(@More_than_a_hundred-1)) as int)
		

		SET @RowCount +=1
	END

--=========================================================
--Угон -10000 
--=========================================================

SELECT @i=0 FROM dbo.Theft WITH (TABLOCKX) WHERE 1=0

	SET @RowCount=1
	
WHILE @RowCount<=@More_than_a_thousand
	BEGIN
		
		
		SET @NameLimit=5+RAND()*15 -- им¤ от 5 до 20 символов
		
		SET @Date_theft=dateadd(day,-RAND()*15000,GETDATE())
		SET @Spent_date=dateadd(day,-RAND()*15000,GETDATE())

		

		INSERT INTO dbo.Theft([Accounting code],[Date theft],[Spent Date] )
		SELECT
		 CAST( (1+RAND()*(@More_than_a_hundred-1)) as int),@Date_theft,@Spent_date
		

		SET @RowCount +=1
	END


	COMMIT TRAN
GO


--Создание представления 
--1
use lab_1
go
CREATE VIEW Owner_filtration1
          AS Select Name, Adress, Birthday
		  from [Owner],Car
		  where Car.[Ownew code]=[Owner].[Ownew code] and Car.Colour='Red'
go
		  select * from Owner_filtration1
drop VIEW Owner_filtration1

--3
use lab_1
go
CREATE VIEW Owner_filtration
          AS Select Name, Adress, Category
		  from [Owner],Car
		  where Car.[Ownew code]=[Owner].[Ownew code] and Car.[Registration number]='233900123'
go
		  select * from Owner_filtration
drop VIEW Owner_filtration

--2

use lab_1
go
CREATE VIEW Owner_filtration2
          AS Select Name, Adress, Category , [Owner].[Ownew code]
		  from [Owner],Car
		  where Car.[Ownew code]=[Owner].[Ownew code] 
go
		  select * from Owner_filtration2
drop VIEW Owner_filtration2
--4
use lab_1
go
CREATE VIEW Owner_filtration3
          AS Select Name="Name"+"Category"+"Additional Information", Adress, [Owner].[Ownew code]
		  from [Owner],Car
		  where Car.[Ownew code]=[Owner].[Ownew code] 
go
		  select * from Owner_filtration3
drop VIEW Owner_filtration3

-- Создание хранимых процедур
--1
use lab_1
go 
Create procedure proc1(@N int )
as 
select Name, Adress, Birthday
 from [Owner],Car
		  where Car.[Ownew code]=@N 
go 
Exec proc1 150

drop procedure proc1
--2
use lab_1
go 
Create procedure proc2(@N nvarchar )
as 
select Name, Adress, Birthday, [Passport data]
 from [Owner]
		  where [Owner].[Number of driving license]=@N
go 
Exec proc2 '999102HB8'

drop procedure proc2
--3
use lab_1
go 
Create procedure proc3(@N nvarchar )
as 
select Name, Adress, Birthday, [Passport data]
 from [Owner]
		  where [Owner].[Number of driving license]=@N
go 
Exec proc3 '2015-07-07'

drop procedure proc3

--4
use lab_1
go 
Create procedure proc4(@M nvarchar )
as 
select Name, Adress, Birthday, [Passport data]
 from [Owner],Car,Mark
		  where Mark.Firm=@M
go 
Exec proc4 'Ford'

drop procedure proc4