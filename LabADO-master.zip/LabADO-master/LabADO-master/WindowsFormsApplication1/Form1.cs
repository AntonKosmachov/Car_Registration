﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {

        SqlDataAdapter dataAdapter = new SqlDataAdapter();
        DataSet ds = new DataSet();

        public Form1()
        {
            InitializeComponent();  
            
        }

        private void buttonFill_Click(object sender, EventArgs e)
        {
            string commandText = Convert.ToString(textBoxCommand.Text);
            string ConnectionString = Convert.ToString(textBoxConnectionString.Text);
            SqlConnection conn = new SqlConnection(ConnectionString);
            labelInfo.Text = "Ход выполнения процесса заполнения базы данных:\r\n";
            labelInfo.Refresh();

            try
            {
                conn.Open();
                labelInfo.Text = labelInfo.Text + "1. cоединение с базой данных установлено;\r\n";
                labelInfo.Refresh();
                SqlCommand MyCommand = conn.CreateCommand();
                MyCommand.CommandText = commandText;
                labelInfo.Text = labelInfo.Text + "2. заполнение таблиц базы данных начато, подождите немного...;\r\n";
                labelInfo.Refresh();

                MyCommand.ExecuteNonQuery();
                labelInfo.Text = labelInfo.Text + "3. заполнение таблиц базы данных окончено!!!\r\n";
                labelInfo.Refresh();

            }
            catch (Exception exeption)
            {
                labelInfo.Text = labelInfo.Text + "Ошибка: "+ exeption.Source;
                labelInfo.Refresh();
            }
            finally
            {
                conn.Close();
            }

        }

        private void buttonDisplay_Click(object sender, EventArgs e)
        {
            string ConnectionString = Convert.ToString(textBoxConnectionString.Text);
            SqlConnection conn = new SqlConnection(ConnectionString);
            labelInfo.Text = "\r\n Ход выполнения процесса визуализации:\r\n";
            labelInfo.Refresh();

            try
            {
                conn.Open();
                ds.Clear();
                labelInfo.Text = labelInfo.Text + "1. cоединение с базой данных установлено;\r\n";
                labelInfo.Refresh();
                SqlCommand MyCommand = new SqlCommand();
                MyCommand.Connection = conn;
                

                labelInfo.Text = labelInfo.Text + "2. отбор данных в локальное хранилище начат;\r\n";
                labelInfo.Refresh();

                MyCommand.CommandText = "SELECT * FROM Car";
                dataAdapter.SelectCommand = MyCommand;
                if (!(ds.Tables.Contains("Car"))) ds.Tables.Add("Car");
                dataAdapter.Fill(ds, "Car"); // 

                MyCommand.CommandText = "SELECT * FROM Owner";
                dataAdapter.SelectCommand = MyCommand;
                if (!(ds.Tables.Contains("Owner"))) ds.Tables.Add("Owner");
                dataAdapter.Fill(ds, "Owner"); // 


                MyCommand.CommandText = "SELECT * FROM Mark";
                dataAdapter.SelectCommand = MyCommand;
                if (!(ds.Tables.Contains("Mark"))) ds.Tables.Add("Mark");
                dataAdapter.Fill(ds, "Mark");

                labelInfo.Text = labelInfo.Text + "3. отбор данных в локальное хранилище закончен;\r\n";
                labelInfo.Refresh();

                dataGridView1.DataSource = ds.Tables["Car"].DefaultView;
                dataGridView2.DataSource = ds.Tables["Owner"].DefaultView;
                dataGridView3.DataSource = ds.Tables["Mark"].DefaultView;

                labelInfo.Text = labelInfo.Text + "4. отображение данных из локального хранилища в табличных элементах управления закончено!!!\r\n";
                labelInfo.Refresh();

            }
            catch (Exception exeption)
            {
                labelInfo.Text = labelInfo.Text + "Ошибка: " + exeption.ToString();
                labelInfo.Refresh();
            }
            finally
            {

                conn.Close();

            }
        }

     

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            string ConnectionString = Convert.ToString(textBoxConnectionString.Text);
            // Использовать фабрику для получения соединения
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = ConnectionString;
            labelInfo.Text = "";
            //значение ключевого поля строки для удаления
            int id = (int)dataGridView1.CurrentRow.Cells[0].Value;

            try
            {
                using (conn)
                {
                    // Определение строки запроса
                    string queryString = "SELECT * FROM Car";

                    // Создать команду на выборку
                    SqlCommand command = new SqlCommand();
                    command.CommandText = queryString;
                    command.Connection = conn;

                    // Создать DbDataAdapter.
                    SqlDataAdapter adapter = new SqlDataAdapter();
                    adapter.SelectCommand = command;

                    // Создать DbCommandBuilder.
                    SqlCommandBuilder builder = new SqlCommandBuilder();
                    builder.DataAdapter = adapter;
                    // Получить команду на удаление
                    adapter.DeleteCommand = builder.GetDeleteCommand();

                    DataTable table = ds.Tables["Car"];

                    // Удаление строки
                    DataRow[] deleteRow = table.Select("Car_code = " + id);
                    foreach (DataRow row in deleteRow)
                    {
                        row.Delete();
                    }
                    adapter.Update(table);
                    table.AcceptChanges();

                }

                labelInfo.Text = labelInfo.Text + "Удалено!!!\r\n";
                labelInfo.Refresh();

            }
            catch (Exception exeption)
            {
                labelInfo.Text = labelInfo.Text + "Ошибка: " + exeption.ToString();
                labelInfo.Refresh();
            }

        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            string ConnectionString = Convert.ToString(textBoxConnectionString.Text);
            SqlConnection conn = new SqlConnection(ConnectionString);

            try
            {
                conn.Open();

                DataTable table = ds.Tables["Car"];
                SqlCommand command = new SqlCommand("UPDATE Car SET Mark_code=@Mark_code, Ownew_code=@Ownew_code, Registration_number=@Registration_number, Car_body_number=@Car_body_number, Engine_number=@Engine_number, Technical_Passport=@Technical_Passport, Release_date=@Release_date, Latest_inspection=@Latest_inspection, Colour=@Colour, Description=@Description WHERE Car_code=@Car_code", conn);
     
                // Добавить парметры для команды обновления
                SqlParameter[] parameters = new SqlParameter[table.Columns.Count];
                int number = 0;
                foreach (DataColumn column in table.Columns)
                {
                    parameters[number] = command.CreateParameter();
                    parameters[number].ParameterName = "@" + column.ColumnName;
                    parameters[number].SourceColumn = column.ColumnName;
                    command.Parameters.Add(parameters[number]);
                    number = number + 1;
                }
                dataAdapter.UpdateCommand = command;
                dataAdapter.Update(table.Select(null, null, DataViewRowState.ModifiedCurrent));

            }
            catch (Exception exeption)
            {
                labelInfo.Text = labelInfo.Text + "Ошибка: " + exeption.ToString();
                labelInfo.Refresh();
            }
            finally
            {
                conn.Close();
            }
        }

        private void buttonSave2_Click(object sender, EventArgs e)
        {
            
        }
        private void buttonDelete2_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBoxConnectionString_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxCommand_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelInfo_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ConnectionString = Convert.ToString(textBoxConnectionString.Text);
            SqlConnection conn = new SqlConnection(ConnectionString);

            try
            {
                conn.Open();

                DataTable table = ds.Tables["Owner"];
                SqlCommand command = new SqlCommand("UPDATE Owner SET Name=@Name, Birthday=@Birthday, Adress=@Adress, Passport_data=@Passport_data, Number_of_driving_license=@Number_of_driving_license, Date_of_issue=@Date_of_issue, Category=@Category, Additional_Information=@Additional_Information WHERE Ownew_code=@Ownew_code", conn);
                // Добавить парметры для команды обновления
                SqlParameter[] parameters = new SqlParameter[table.Columns.Count];
                int number = 0;
                foreach (DataColumn column in table.Columns)
                {
                    parameters[number] = command.CreateParameter();
                    parameters[number].ParameterName = "@" + column.ColumnName;
                    parameters[number].SourceColumn = column.ColumnName;
                    command.Parameters.Add(parameters[number]);
                    number = number + 1;
                }
                dataAdapter.UpdateCommand = command;
                dataAdapter.Update(table.Select(null, null, DataViewRowState.ModifiedCurrent));

            }
            catch (Exception exeption)
            {
                labelInfo.Text = labelInfo.Text + "Ошибка: " + exeption.ToString();
                labelInfo.Refresh();
            }
            finally
            {
                conn.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string ConnectionString = Convert.ToString(textBoxConnectionString.Text);
            // Использовать фабрику для получения соединения
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = ConnectionString;
            labelInfo.Text = "";
            //значение ключевого поля строки для удаления
            int id = (int)dataGridView2.CurrentRow.Cells[0].Value;

            try
            {
                using (conn)
                {
                    // Определение строки запроса
                    string queryString = "SELECT * FROM Owner";

                    // Создать команду на выборку
                    SqlCommand command = new SqlCommand();
                    command.CommandText = queryString;
                    command.Connection = conn;

                    // Создать DbDataAdapter.
                    SqlDataAdapter adapter = new SqlDataAdapter();
                    adapter.SelectCommand = command;

                    // Создать DbCommandBuilder.
                    SqlCommandBuilder builder = new SqlCommandBuilder();
                    builder.DataAdapter = adapter;
                    // Получить команду на удаление
                    adapter.DeleteCommand = builder.GetDeleteCommand();

                    DataTable table = ds.Tables["Owner"];

                    // Удаление строки
                    DataRow[] deleteRow = table.Select("Ownew_code = " + id);
                    foreach (DataRow row in deleteRow)
                    {
                        row.Delete();
                    }
                    adapter.Update(table);
                    table.AcceptChanges();

                }

                labelInfo.Text = labelInfo.Text + "Удалено!!!\r\n";
                labelInfo.Refresh();

            }
            catch (Exception exeption)
            {
                labelInfo.Text = labelInfo.Text + "Ошибка: " + exeption.ToString();
                labelInfo.Refresh();
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string ConnectionString = Convert.ToString(textBoxConnectionString.Text);
            SqlConnection conn = new SqlConnection(ConnectionString);

            try
            {
                conn.Open();

                DataTable table = ds.Tables["Mark"];
                SqlCommand command = new SqlCommand("UPDATE Mark SET Firm=@Firm, Manufacturer_country=@Manufacturer_country WHERE Mark_code=@Mark_code", conn);
                // Добавить парметры для команды обновления
                SqlParameter[] parameters = new SqlParameter[table.Columns.Count];
                int number = 0;
                foreach (DataColumn column in table.Columns)
                {
                    parameters[number] = command.CreateParameter();
                    parameters[number].ParameterName = "@" + column.ColumnName;
                    parameters[number].SourceColumn = column.ColumnName;
                    command.Parameters.Add(parameters[number]);
                    number = number + 1;
                }
                dataAdapter.UpdateCommand = command;
                dataAdapter.Update(table.Select(null, null, DataViewRowState.ModifiedCurrent));

            }
            catch (Exception exeption)
            {
                labelInfo.Text = labelInfo.Text + "Ошибка: " + exeption.ToString();
                labelInfo.Refresh();
            }
            finally
            {
                conn.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string ConnectionString = Convert.ToString(textBoxConnectionString.Text);
            // Использовать фабрику для получения соединения
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = ConnectionString;
            labelInfo.Text = "";
            //значение ключевого поля строки для удаления
            int id = (int)dataGridView3.CurrentRow.Cells[0].Value;

            try
            {
                using (conn)
                {
                    // Определение строки запроса
                    string queryString = "SELECT * FROM Mark";

                    // Создать команду на выборку
                    SqlCommand command = new SqlCommand();
                    command.CommandText = queryString;
                    command.Connection = conn;

                    // Создать DbDataAdapter.
                    SqlDataAdapter adapter = new SqlDataAdapter();
                    adapter.SelectCommand = command;

                    // Создать DbCommandBuilder.
                    SqlCommandBuilder builder = new SqlCommandBuilder();
                    builder.DataAdapter = adapter;
                    // Получить команду на удаление
                    adapter.DeleteCommand = builder.GetDeleteCommand();

                    DataTable table = ds.Tables["Mark"];

                    // Удаление строки
                    DataRow[] deleteRow = table.Select("Mark_code = " + id);
                    foreach (DataRow row in deleteRow)
                    {
                        row.Delete();
                    }
                    adapter.Update(table);
                    table.AcceptChanges();

                }

                labelInfo.Text = labelInfo.Text + "Удалено!!!\r\n";
                labelInfo.Refresh();

            }
            catch (Exception exeption)
            {
                labelInfo.Text = labelInfo.Text + "Ошибка: " + exeption.ToString();
                labelInfo.Refresh();
            }
        }
    }
}
